#!/usr/bin/env node
// Starmux npm release artifact inspector v1.1.
// Offline, read-only: inspect the exact built .tgz; never publish or contact registries.
import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';

const [tarballArg, expectedVersion, localServerArg] = process.argv.slice(2);
if (!tarballArg) {
  console.error('Usage: node inspect-tarball.mjs <starmux-VERSION.tgz> [VERSION] [./server.json]');
  process.exit(2);
}

const tarball = resolve(tarballArg);
const fail = (message) => { throw new Error(message); };

function tar(args) {
  const result = spawnSync('tar', args, { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  if (result.error || result.status !== 0) {
    fail('tar ' + args[0] + ' failed: ' + (result.stderr || result.error?.message || '').trim());
  }
  return result.stdout;
}

function parseJson(text, label) {
  try { return JSON.parse(text); }
  catch (error) { fail('Invalid ' + label + ': ' + error.message); }
}

function assertEqual(actual, expected, message) {
  if (actual !== expected) fail(message + ' (expected ' + JSON.stringify(expected) + ', got ' + JSON.stringify(actual) + ')');
}

try {
  const members = new Set(tar(['-tzf', tarball]).trim().split(/\r?\n/));
  const required = [
    'package/package.json',
    'package/server.json',
    'package/README.md',
    'package/LICENSE',
    'package/bin/starmux.mjs',
    'package/scripts/prepare.mjs',
    'package/dist/vendor/desktop-commander/dist/index.js',
    'package/dist/vendor/desktop-commander/package.json',
    'package/dist/vendor/desktop-commander/LICENSE',
  ];
  for (const member of required) {
    if (!members.has(member)) fail('Missing package entry: ' + member);
  }
  if (![...members].some((name) => /^package\/dist\/src\/[^/]+\.js$/.test(name))) {
    fail('Missing compiled Starmux runtime in package/dist/src/');
  }

  const manifest = parseJson(tar(['-xOf', tarball, 'package/package.json']), 'packaged package.json');
  const server = parseJson(tar(['-xOf', tarball, 'package/server.json']), 'packaged server.json');
  const vendor = parseJson(
    tar(['-xOf', tarball, 'package/dist/vendor/desktop-commander/package.json']),
    'packaged Desktop Commander manifest'
  );

  assertEqual(manifest.name, 'starmux', 'Unexpected npm package');
  if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(manifest.version || '')) {
    fail('Missing or invalid npm semantic version');
  }
  if (expectedVersion) assertEqual(manifest.version, expectedVersion, 'Unexpected npm version');
  if (!manifest.description || manifest.description.length < 40) fail('Missing/short npm description');
  if (!Array.isArray(manifest.keywords)
      || !manifest.keywords.includes('mcp')
      || !manifest.keywords.includes('self-hosted')) {
    fail('Missing npm discovery keywords mcp/self-hosted');
  }
  assertEqual(manifest.bin?.starmux, 'bin/starmux.mjs', 'Invalid npm binary entry');

  // Required by the official MCP Registry for npm package ownership verification.
  const expectedMcpName = 'io.github.cookyecat/starmux';
  assertEqual(manifest.mcpName, expectedMcpName, 'Missing or incorrect npm mcpName');
  assertEqual(server.name, manifest.mcpName, 'MCP Registry server name mismatches npm mcpName');
  assertEqual(server.version, manifest.version, 'Registry server version mismatches npm version');
  if (!server.title || !server.description) fail('Registry server title/description is missing');
  assertEqual(
    (server.repository?.url || '').replace(/\.git\/?$/, '').replace(/\/$/, ''),
    'https://github.com/cookyecat/starmux',
    'Registry repository URL mismatches Starmux GitHub'
  );

  if (!Array.isArray(server.packages)) fail('Registry packages list is missing');
  const npmPackages = server.packages.filter((p) => p.registryType === 'npm' && p.identifier === manifest.name);
  if (npmPackages.length !== 1) fail('Expected exactly one npm package entry for starmux in server.json');
  const pkg = npmPackages[0];
  assertEqual(pkg.version, manifest.version, 'Registry npm package version mismatches npm version');
  if (pkg.registryBaseUrl && pkg.registryBaseUrl !== 'https://registry.npmjs.org') {
    fail('Unexpected registryBaseUrl: ' + pkg.registryBaseUrl);
  }
  assertEqual(pkg.transport?.type, 'streamable-http', 'Unexpected MCP transport type');
  if (!pkg.transport?.url || !/^https?:\/\//.test(pkg.transport.url)) {
    fail('Registry package streamable-http transport URL is missing or malformed');
  }

  assertEqual(vendor.name, '@wonderwhy-er/desktop-commander', 'Unexpected bundled upstream package');
  if (!/^\d+\.\d+\.\d+/.test(vendor.version || '')) fail('Bundled Desktop Commander version missing');

  // Optional strict check: the prepared tarball must contain the same metadata as the local checkout.
  if (localServerArg) {
    const localServerPath = resolve(localServerArg);
    const localServerRaw = readFileSync(localServerPath, 'utf8');
    const tarServerRaw = tar(['-xOf', tarball, 'package/server.json']);
    if (localServerRaw !== tarServerRaw) {
      fail('Local server.json differs from the frozen tarball; inspect changes, do not silently repack');
    }
    const localPackagePath = join(dirname(localServerPath), 'package.json');
    if (existsSync(localPackagePath)) {
      const localPackage = parseJson(readFileSync(localPackagePath, 'utf8'), 'local package.json');
      assertEqual(localPackage.name, manifest.name, 'Local npm package name differs from tarball');
      assertEqual(localPackage.version, manifest.version, 'Local npm version differs from tarball');
      assertEqual(localPackage.mcpName, manifest.mcpName, 'Local npm mcpName differs from tarball');
    }
  }

  const checksum = createHash('sha256').update(readFileSync(tarball)).digest('hex');
  console.log(JSON.stringify({
    status: 'PASS',
    inspectorVersion: '1.1',
    package: manifest.name,
    version: manifest.version,
    mcpName: manifest.mcpName,
    registryServer: server.name,
    registryVersion: server.version,
    transport: pkg.transport.type,
    bundledDesktopCommander: vendor.version,
    description: manifest.description,
    keywords: manifest.keywords,
    totalFiles: members.size,
    tarball,
    sha256: checksum,
    localMetadataChecked: Boolean(localServerArg),
  }, null, 2));
} catch (error) {
  console.error('Artifact inspection FAILED: ' + error.message);
  process.exitCode = 1;
}
