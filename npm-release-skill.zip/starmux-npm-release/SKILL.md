---
name: starmux-npm-release
description: Prepare, inspect, and publish Starmux npm releases and optionally register them in the official MCP Registry. v1.1 validates mcpName/server.json, the bundled Desktop Commander runtime, exact tarballs, and separate npm/Registry publication approvals.
---

# Starmux npm release — v1.1

Use this workflow for the `starmux` npm package in `cookyecat/starmux`, including optional publication to the **official MCP Registry**. Keep operational release instructions in this installed Skill, not in the product repository; do not create repository-level release scripts or policies just for this workflow.

The workflow has **three separate stages**: (A) prepare and verify, (B) publish to npm, (C) publish the corresponding version to the MCP Registry. The user can request any stage independently.

## Non-negotiable rules

1. **Two independent publish approvals.** Preparing, building, testing, packing, inspecting or validating never authorizes publication. Require explicit authorization for the exact version and artifact before `npm publish`. Require a **separate explicit authorization** before `mcp-publisher publish`. Do not infer permission from prior releases or login success.
2. **Build once; inspect the exact tarball; publish that same tarball.** Never silently rebuild or repack after verification; record SHA-256 and check it again before publishing. Always use `npm publish ./starmux-VERSION.tgz`, never `npm publish .`.
3. **No credential exposure.** Never print `.npmrc`, auth files, access tokens, token-bearing environment variables, or full npm debug logs. The user handles interactive npm login, GitHub device authorization, 2FA and browser prompts on their own computer. Never copy a device code into chat.
4. **Stop on any failure.** Never change a version or permission to work around E401/E403/E404/2FA, skip tests, override security safeguards, or repeatedly retry publication without diagnosing the cause. Published npm versions are immutable.
5. **Protect Git state.** Check `git status --short --branch` and the intended repository before edits. Do not discard user changes, force-push, tag, commit or push without appropriate instruction. Use `git pull --ff-only` only after checking local work.
6. **Keep upstream pinned.** The build vendors a purified copy of `@wonderwhy-er/desktop-commander` into `dist/vendor/desktop-commander`. It is a build-time devDependency, not a separately installed production runtime package. Do not run `npm run sync:upstream` or silently change its version as part of a routine release.
7. **Accurate claims.** Starmux's local Read-only/Coding modes and MCP authentication do not establish an OS sandbox. The official MCP Registry publishes metadata, not code, and its publication does not guarantee inclusion in third-party directories.

## A. Prepare and inspect an npm release — no registry mutation

1. Go to the Starmux source repository and inspect `git status`, `git remote -v`, `package.json`, `package-lock.json`, `CHANGELOG.md` and `server.json`.
2. Confirm the intended version `VERSION` has **not** already been published: `npm view starmux@VERSION version --registry=https://registry.npmjs.org`. If found, stop; do not attempt overwriting.
3. If the user requests a version bump, synchronize:
   - Root `package.json` and both root version entries in `package-lock.json`.
   - The intended version in `CHANGELOG.md` (when following the project's changelog convention).
   - `server.json` top-level `version` and matching `packages[].version`.
   - `package.json` `mcpName` and `server.json` `name` must both equal `io.github.cookyecat/starmux`.
   - Ensure `server.json` identifies npm package `starmux` and its documented Streamable HTTP transport.
   - Use the project's established versioning command if necessary, e.g. `npm version VERSION --no-git-tag-version --ignore-scripts`. Do **not** bump a version that is already correct.
4. Restore dependencies and run the existing full checks:

```bash
cd /Users/liyang/Developer/mac-mcp-gateway-typescript
npm ci --include=dev
npm run typecheck
npm run build
npm test
git diff --check
git status --short --branch
```

   `npm ci --include=dev` restores `typescript` and the **pinned** upstream build dependency even if `node_modules` was deleted. If any step fails, stop. Do not change product code just to pass a release check without user instruction.

5. Create the artifact **without running prepack/prepare lifecycle scripts again**:

```bash
npm pack --ignore-scripts
tar -tzf starmux-VERSION.tgz
node ~/.agents/skills/starmux-npm-release/scripts/inspect-tarball.mjs \
  ./starmux-VERSION.tgz VERSION ./server.json
```

   The v1.1 inspector reads the **actual tarball**, not just the local source: it checks npm identity and semver; npm discovery keywords; `mcpName`; bundled `server.json` name/version/npm package and transport; the CLI entry; compiled Starmux JS; the bundled Desktop Commander entry, license and manifest; and strict agreement with local `server.json` and `package.json` when the third argument is supplied. It emits SHA-256 and makes **no network or registry mutations**.

6. Record the tarball path, SHA-256, version, Git commit, and any reviewed working-tree changes. Preserve the **same .tgz bytes** for npm publishing. A changed local `server.json` after packing is a mismatch, not permission to auto-repack.

## B. Publish the verified tarball to npm — explicit authorization required

1. Confirm the user authorized publishing **this exact VERSION and tarball**.
2. Check credentials and ownership (read-only checks):

```bash
npm whoami --registry=https://registry.npmjs.org
npm owner ls starmux --registry=https://registry.npmjs.org
npm view starmux@VERSION version --registry=https://registry.npmjs.org
shasum -a 256 starmux-VERSION.tgz
```

   The npm account must have actual publish rights. If `whoami` returns E401, have the user perform `npm login --auth-type=web --registry=https://registry.npmjs.org` and any 2FA interaction locally. If the intended version exists, **do not republish**. Compare the SHA-256 against the prepared artifact.

3. Publish only after the explicit approval:

```bash
npm publish ./starmux-VERSION.tgz \
  --ignore-scripts \
  --access public \
  --tag latest \
  --registry=https://registry.npmjs.org
```

4. Verify the actual npm registry metadata:

```bash
npm view starmux@VERSION version --registry=https://registry.npmjs.org
npm view starmux@VERSION mcpName --registry=https://registry.npmjs.org
npm view starmux@VERSION description --registry=https://registry.npmjs.org
npm view starmux dist-tags --json --registry=https://registry.npmjs.org
git status --short --branch
```

   The published `mcpName` must be `io.github.cookyecat/starmux`. If metadata is ambiguous or missing, inspect the **published** npm tarball's `package/package.json` as well, not merely the local package. Do not claim npm publication until the registry confirms it.

## C. Publish to the official MCP Registry — separate authorization required

**Preconditions:** The matching npm version is already publicly published; `npm view starmux@VERSION mcpName` resolves to `io.github.cookyecat/starmux`; and the local `server.json` matches that version and passed the artifact inspector. The CLI being installed or the user already being logged in does **not** authorize this stage.

1. Verify the local `server.json` without publishing:

```bash
mcp-publisher validate server.json
```

   On a machine where the Go HTTP/2 client returns `EOF` despite a reachable Registry (observed on this Mac), retry **validation** with:

```bash
GODEBUG=http2client=0 mcp-publisher validate server.json
```

   If validation fails with a genuine schema or semantic error, fix and revalidate **before** any publication. Do not use a direct `curl` request as evidence that ownership verification or publication succeeded.

2. For authentication, instruct the user to complete the GitHub device authorization locally if needed:

```bash
mcp-publisher login github
```

   The GitHub identity must control `io.github.cookyecat/starmux`. This is different from `gh auth login` and npm authentication. Never display the resulting authentication code, credentials or JWT in chat.

3. Before publishing, check whether the **exact server name and version** are already recorded; if so, report success rather than blindly publishing again. A broad query is discovery evidence, not proof of a specific version:

```bash
curl -fsSL 'https://registry.modelcontextprotocol.io/v0.1/servers?search=io.github.cookyecat%2Fstarmux'
```

4. After **separate explicit authorization** for the exact Registry VERSION, publish:

```bash
GODEBUG=http2client=0 mcp-publisher publish server.json
```

   The `GODEBUG` setting is a host-specific workaround for the previously observed CLI transport failure; it is not part of the Registry's security or validation contract. Do not use `--registry` with `publish`; it uses the URL stored at login.

5. Verify that the Registry API returns the **exact** `io.github.cookyecat/starmux` and `VERSION` (not merely a substring match). If search indexing lags, distinguish "CLI reported successful publish" from "query is currently visible"; do not republish impulsively.

   Official registry documentation:
   - https://github.com/modelcontextprotocol/registry/blob/main/docs/modelcontextprotocol-io/quickstart.mdx
   - https://github.com/modelcontextprotocol/registry/blob/main/docs/reference/cli/commands.md
   - https://github.com/modelcontextprotocol/registry/blob/main/docs/reference/server-json/official-registry-requirements.md

## Diagnose publication failures (read-only first)

- **npm E401:** missing, expired or wrong npm credentials. Use `npm whoami`; user fixes login locally.
- **npm E403:** ownership, token scope, package-level policy or 2FA; check `npm owner ls starmux` and publishing rights, not just read access.
- **npm E404 on PUT:** the package may still exist; inspect current published versions, authenticated identity and authorization. Do not assume the package name is available, and do not bump the version as an authentication workaround.
- **Published npm package lacks `mcpName`:** local `package.json` is not evidence. Inspect the published tarball; correct the package metadata in a **new** npm version after authorization.
- **Registry invalid package ownership:** check `mcpName` in the exact npm version and `server.json` name/package references; the official Registry needs published package ownership evidence.
- **Registry namespace denial or expired token:** confirm the GitHub account controls `cookyecat` and reauthenticate locally; do not substitute namespace names without authorization.
- **Publisher `EOF`:** reproduce with `GODEBUG=http2client=0`; distinguish network/HTTP2 errors from server.json validation errors.
- **Registry result not yet visible:** verify the exact name/version later; registry publication and third-party directory indexing are independent.

## Completion report

Report three statuses independently: **artifact prepared**, **npm published**, **MCP Registry published**. Include verified version, immutable artifact path and SHA-256, current Git commit, upstream Desktop Commander bundle version, validation status, official Registry lookup and any blockers. Never claim a publish action occurred unless the target registry or CLI has confirmed it.

`v1.1 change summary:` Added packaged ownership metadata and three-way version checks, bundled-upstream validation, optional strict local/package metadata agreement, independent official MCP Registry authorization/publish stage, Go HTTP/2 EOF workaround, and more explicit verification of the published npm package.
